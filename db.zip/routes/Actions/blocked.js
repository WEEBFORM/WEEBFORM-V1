import express from "express";
import { blockUser, unblockUser,getBlockedUsers } from "../../controllers/Actions/blockedController"
const router = express.Router();

router.post('/block/blockUser', blockUser);
router.delete('/unblock/:blockedUser', unblockUser);
router.get('/blockedUsers', getBlockedUsers)


export default router