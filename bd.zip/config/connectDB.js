import mysql from "mysql2/promise";
import { config } from "dotenv";
config();

export const db = await mysql.createConnection({
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB
});

db.connect()
    .then(() => console.log("Connected to MySQL"))
    .catch((err) => console.error("Error connecting to MySQL:", err));
