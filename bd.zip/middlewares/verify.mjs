import { verifyToken } from './utils.js';

export const authenticateUser = (roles = []) => {
  return (req, res, next) => {
    const token = req.cookies.accessToken;

    if (!token) {
      return res.status(401).json({ error: 'Unauthorized - No token provided' });
    }

    try {
      const user = verifyToken(token);
      req.user = user;

      if (roles.length && !roles.includes(user.role)) {
        return res.status(403).json({ error: 'Unauthorized - Insufficient privileges' });
      }

      next();
    } catch (err) {
      console.error("Token verification error:", err);
      return res.status(403).json({ error: 'Invalid token' });
    }
  };
};

export default authenticateUser;
