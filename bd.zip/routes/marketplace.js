import express from "express";
import { 
    newStore, 
    viewStores, 
    editStoreDetails, 
    closeStore, 
    viewSingleStore,
    addCatalogueItem,
    getCatalogueItems,
    editCatalogueItem,
    deleteCatalogueItem
} from "../controllers/Marketplace/stores.js";

const router = express.Router();

// STORE ENDPOINTS
router.post('/create', newStore);
router.get('/', viewStores);
router.get('/:id', viewSingleStore);
router.put('/edit-store-details/:id', editStoreDetails);
router.delete('/close-store/:id', closeStore);

// CATALOGUE ENPOINTS
router.post('/:id/catalogue', addCatalogueItem);
router.get('/catalogue/:storeId', getCatalogueItems);
router.put('/catalogue/edit/:id', editCatalogueItem);
router.delete('/catalogue/:id', deleteCatalogueItem);

export default router;