const BANNED_KEYWORDS = [
    "fuck", "dickhead", "shit", "bitch", "cunt",
    "asshole", "bastard", "slut", "whore", "pussy",
    "dick", "cock", "nigga", "nigger"
];

export default BANNED_KEYWORDS;