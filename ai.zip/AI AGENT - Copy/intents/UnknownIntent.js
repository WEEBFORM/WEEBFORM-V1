class UnknownIntent {
    async execute() {
        return "Gomen nasai! I could not understand that command"
    }
}

export default UnknownIntent;